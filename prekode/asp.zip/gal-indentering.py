# Dette programmet starter med en del rar men lovlig indentering
# fÃ¸r det til sist viser en ulovlig indentering.

if True:
 if False:  # Indentering (kort men helt lovlig)
                              if 1: # Kjempeindentering (uleselig men OK)
                                  print("Ja")
    a = 4   # Gal indentering (ikke brukt fÃ¸r)

# Dette programmet inneholder en tekststreng som ikke avsluttes pÃ¥
# samme linje.

t1 = "Denne er OK"
t2 = 'Denne ogsÃ¥'
t3 = 'Denne starter her
      og slutter pÃ¥ neste linje. Det er ikke lov!'
